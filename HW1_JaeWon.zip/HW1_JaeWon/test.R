# colnames(x)[2] <- "name"
# 
# redundant parts
# -number of parameters (runif)
# -lower/upper bound
# -mle_model_XXX value as Inf initially
# -new runif generation for each iteration on the go
# -draw with ggplot in for loop --> maybe use apply?
# -make MLE iteration into function (including if comparison and saving to df)
# -

